$().ready(function(){
	$('#navbar').scrollspy();
});